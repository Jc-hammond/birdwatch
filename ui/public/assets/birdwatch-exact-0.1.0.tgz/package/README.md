# Birdwatch for Expo Exact

Install the downloaded package beside your Exact app’s package.json.

```sh
npm install ./birdwatch-exact-0.1.0.tgz
```

In your TypeScript data module, grant access to the collector’s origin and pass the module’s scoped fetch. Put capture in a Contract mutation triggered by a user action. A resource can run on bake, refresh or replay.

```ts
import { createExactClient } from "@birdwatch/exact";

const host = "https://analytics.example.com";
export const grants = `net.fetch ${host}`;
const analytics = createExactClient({ host, writeKey: "YOUR_PROJECT_WRITE_KEY", fetch });

// Inside an answer, use the durable ID of the action you are reporting.
const completeCheckout = (person: string, orderId: string) =>
  analytics.capture({
    id: "checkout:" + orderId, distinctId: person, event: "checkout_completed",
    properties: { orderId }
  });
```

The package includes a working Contract and TypeScript data module in `example/`. Copy its three files into an Exact app, replace the host and write key in `app.ts`, and build with your Exact checkout. The “Record completion” button represents one completion for a demo user. Pressing it again acknowledges the same event. For actions that repeat, pass a different stable ID per occurrence. Event IDs are unique within a Birdwatch project.

`capture(event)` sends one event. `captureBatch(events)` sends 1–100 events atomically and returns `{ accepted, duplicates }`. The SDK performs a single request per call. Retry a failed mutation with the original event IDs. The collector assigns the timestamp unless you supply an ISO 8601 string with a time zone. Set `timeoutMs` to change the default 5,000 ms Exact fetch deadline.

The example was compiled with [Expo Exact at bb3c00b](https://github.com/expo/exact/tree/bb3c00b957ce6d547665ec8f4b79cfe2def72b08).
