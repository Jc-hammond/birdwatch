import { createExactClient } from "@birdwatch/exact";
import type { Answer, Sources } from "./app.contract.d.ts";

const host = "http://127.0.0.1:8123";
export const grants = `net.fetch ${host}`;
const client = createExactClient({ host, writeKey: "YOUR_PROJECT_WRITE_KEY", fetch });

const sources: Sources = {
  recordCompletion: ([distinctId, id]) =>
    client.capture({ id, distinctId, event: "onboarding_completed", properties: { step: "welcome" } })
};
export const answer: Answer = (source, args, store, storage, native) =>
  sources[source](args, store, storage, native);
