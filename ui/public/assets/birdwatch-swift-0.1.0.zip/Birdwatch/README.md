# Birdwatch for Swift

Unzip `birdwatch-swift-0.1.0.zip`. In Xcode, choose **File → Add Package Dependencies → Add Local**, select the extracted folder containing `Package.swift`, and add the **Birdwatch** product to your target. For a Swift package, add `.package(path: "../Birdwatch")` to dependencies and `.product(name: "Birdwatch", package: "Birdwatch")` to your target.

```swift
import Foundation
import Birdwatch

let client = try BirdwatchClient(host: URL(string: "https://analytics.example.com")!,
                                 writeKey: "YOUR_PROJECT_WRITE_KEY")
try await client.identify("user-42")
try await client.screen("Checkout")
let receipt = try await client.capture("checkout_completed",
    properties: ["orderId": "order-123", "total": 54], id: "checkout:order-123")
await client.reset()
```

The package uses Swift concurrency and Foundation on iOS 15+ and macOS 12+. Create one client per project. The actor persists identity in UserDefaults, scoped to collector and write key. Set `persistence: .memory` for an ephemeral identity. Identify affects subsequent captures. Reset creates a fresh anonymous ID.

Each awaited call sends its event immediately with a fixed ID, occurrence time and identity. Up to two retries use the same body on eligible connection errors, HTTP 408, 429 or 5xx. Set `timeout` in seconds and `maxRetries` when creating the client. A long Retry-After is surfaced as an HTTP error so the app can reschedule. A receipt gives you the occurrence ID and accepted/duplicate counts. Transport, encoding, HTTP and acknowledgement failures throw. Pending delivery lives in memory for the lifetime of the task. For application-level retries, store the occurrence ID alongside your action. Use a device-reachable HTTPS collector URL on physical devices.

Run `swift test` to check the package. Set `BIRDWATCH_TEST_HOST` and `BIRDWATCH_TEST_KEY` to additionally exercise a live collector.
