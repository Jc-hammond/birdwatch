# Birdwatch for React Native

Install the downloaded package in your app. For Expo projects, install the two Expo-compatible helpers used in this example.

```sh
npm install ./birdwatch-react-native-0.1.0.tgz
npx expo install expo-crypto @react-native-async-storage/async-storage
```

```ts
import { createReactNativeClient } from "@birdwatch/react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { randomUUID } from "expo-crypto";

type Events = { checkout_completed: { orderId: string; total: number } };
const analytics = await createReactNativeClient<Events>({
  host: "https://analytics.example.com",
  writeKey: "YOUR_PROJECT_WRITE_KEY",
  storage: AsyncStorage,
  randomUUID,
});

await analytics.identify("user-42");
await analytics.screen("Checkout");
const receipt = await analytics.capture("checkout_completed",
  { orderId: "order-123", total: 54 }, { id: "checkout:order-123" });
await analytics.reset(); // Start a new anonymous identity on logout.
```

Create one client per project after your app has permission to collect analytics. Capture is explicit. Supply a stable screen name when navigation settles. The SDK includes no automatic interaction tracking.

Without a storage adapter the identity lives for this client’s lifetime. In a bare React Native app you can pass any secure UUID generator and an object implementing async `getItem` and `setItem`. Passing `randomUUID` is optional when the host supplies `crypto.randomUUID`.

Each capture snapshots identity and properties. Its promise resolves after the collector acknowledges the batch, including duplicates. Use the same occurrence ID when retrying an action. The default memory queue holds up to 1,000 events, sends batches of up to 20 after 150 ms, and retries transient failures twice. Set `batchSize`, `flushIntervalMs`, `maxQueueSize`, `timeoutMs`, `maxRetries`, or `onError` to tune delivery. Background or inactive AppState transitions request a flush. OS suspension or termination can discard queued events. Await `flush()` for delivery of outstanding events or `shutdown()` to drain and remove the listener. Catch rejections on awaited calls.
