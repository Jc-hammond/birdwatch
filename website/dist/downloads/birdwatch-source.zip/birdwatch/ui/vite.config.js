import { defineConfig } from "vite";
export default defineConfig({
  build: { outDir: "../static", emptyOutDir: true },
});
